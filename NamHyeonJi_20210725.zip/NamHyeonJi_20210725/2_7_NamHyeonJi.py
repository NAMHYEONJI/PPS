def backspaceCompare(s, t):
        """
        :type s: str
        :type t: str
        :rtype: bool
        """
        s1=[]

        for i in s:
            if i=="#" and s1:
                s1.pop()
            else:
                if i!="#":
                    s1.append(i)
        s2=[]    
        for i in t:
            if i=="#" and s2:
                s2.pop()
            else:
                if i!="#":
                    s2.append(i)

        return s1==s2
            


   