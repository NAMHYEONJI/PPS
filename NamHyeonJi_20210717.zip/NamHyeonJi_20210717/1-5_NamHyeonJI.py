class Solution(object):
    def plusOne(self, digits):
            """
            :type digits: List[int]
            :rtype: List[int]
            """
            print(self.digits)

    digits = [4,3,2,1]
    print(plusOne(digits))
